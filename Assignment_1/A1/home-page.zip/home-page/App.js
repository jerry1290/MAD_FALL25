import * as React from "react";
import { Text, View, Button, StyleSheet } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

const Stack = createNativeStackNavigator();

// -------- Home Screen --------
function Home({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>👋 Welcome to SkillSwap</Text>
      <Text style={styles.text}>
        Learn new skills and share your knowledge with others!
      </Text>

      <View style={{ marginTop: 20 }}>
        <Button
          title="Go to Dashboard 📚"
          onPress={() => navigation.navigate("Dashboard")}
          color="#3b82f6"
        />
      </View>
    </View>
  );
}

// -------- Dashboard Screen --------
function Dashboard({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>📚 SkillSwap Dashboard</Text>
      <Text style={styles.text}>- Ali can teach Web Development</Text>
      <Text style={styles.text}>- Sara can teach Graphic Design</Text>
      <Text style={styles.text}>- Ahmed can teach Mobile Apps</Text>

      <View style={{ marginTop: 20 }}>
        <Button
          title="Go to Profile 👤"
          onPress={() => navigation.navigate("Profile")}
          color="#f59e0b"
        />
      </View>
    </View>
  );
}

// -------- Profile Screen --------
function Profile({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>👤 My Profile</Text>
      <Text style={styles.text}>Name: Ali</Text>
      <Text style={styles.text}>Skill: Web Development</Text>
      <Text style={styles.text}>Bio: I love coding and teaching others!</Text>

      <View style={{ marginTop: 20 }}>
        <Button
          title="⬅ Back to Dashboard"
          onPress={() => navigation.goBack()}
          color="#10b981"
        />
      </View>
    </View>
  );
}

// -------- Main App --------
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={Home} />
        <Stack.Screen name="Dashboard" component={Dashboard} />
        <Stack.Screen name="Profile" component={Profile} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

// -------- Styles --------
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#1e293b",
    alignItems: "center",
    justifyContent: "center",
    padding: 20,
  },
  title: {
    fontSize: 24,
    color: "#fbbf24",
    marginBottom: 20,
    fontWeight: "bold",
    textAlign: "center",
  },
  text: {
    fontSize: 18,
    color: "#f1f5f9",
    marginBottom: 10,
    textAlign: "center",
  },
});
