import * as React from "react";
import { useState } from "react";
import {
  Text,
  View,
  Button,
  TextInput,
  StyleSheet,
  TouchableOpacity,
} from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

const Stack = createNativeStackNavigator();

// -------- Create Post Screen --------
function CreatePost({ navigation }) {
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [message, setMessage] = useState("");

  const handlePost = () => {
    if (title && desc) {
      setMessage(`✅ Post Created!\nTitle: ${title}\nDescription: ${desc}`);
      setTitle("");
      setDesc("");
    } else {
      alert("⚠ Please fill in all fields");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>📝 Create a New Post</Text>

      <TextInput
        style={styles.input}
        placeholder="Enter Post Title"
        placeholderTextColor="#94a3b8"
        value={title}
        onChangeText={setTitle}
      />

      <TextInput
        style={[styles.input, { height: 100, textAlignVertical: "top" }]}
        placeholder="Enter Description"
        placeholderTextColor="#94a3b8"
        value={desc}
        onChangeText={setDesc}
        multiline
      />

      <View style={{ width: "60%", marginTop: 10 }}>
        <Button title="Create Post" onPress={handlePost} color="#22c55e" />
      </View>

      {message ? <Text style={styles.message}>{message}</Text> : null}

      <TouchableOpacity
        style={{ marginTop: 20 }}
        onPress={() => navigation.navigate("Home")}
      >
        <Text style={{ color: "#fbbf24" }}>⬅ Back to Home</Text>
      </TouchableOpacity>
    </View>
  );
}

// -------- Home Screen --------
function Home({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>👋 Welcome to SkillSwap</Text>
      <Button
        title="Go to Create Post 📝"
        onPress={() => navigation.navigate("CreatePost")}
        color="#f59e0b"
      />
    </View>
  );
}

// -------- App Main --------
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={Home} />
        <Stack.Screen name="CreatePost" component={CreatePost} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

// -------- Styles --------
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#1e293b",
    alignItems: "center",
    justifyContent: "center",
    padding: 20,
  },
  title: {
    fontSize: 24,
    color: "#fbbf24",
    marginBottom: 20,
    fontWeight: "bold",
  },
  input: {
    width: "90%",
    borderWidth: 1,
    borderColor: "#475569",
    backgroundColor: "#334155",
    borderRadius: 8,
    padding: 10,
    marginBottom: 15,
    color: "#f1f5f9",
  },
  message: {
    marginTop: 20,
    fontSize: 16,
    color: "#4ade80",
    textAlign: "center",
  },
});
