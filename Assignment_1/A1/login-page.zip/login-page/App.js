import * as React from "react";
import { useState } from "react";
import {
  Text,
  View,
  Button,
  TextInput,
  StyleSheet,
  TouchableOpacity,
} from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

const Stack = createNativeStackNavigator();

// -------- Login Screen --------
function Login({ navigation }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = () => {
    if (email && password) {
      navigation.navigate("Dashboard");
    } else {
      alert("⚠ Please enter Email and Password");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>🔑 Login to SkillSwap</Text>

      <TextInput
        style={styles.input}
        placeholder="Enter Email"
        placeholderTextColor="#94a3b8"
        value={email}
        onChangeText={setEmail}
      />

      <TextInput
        style={styles.input}
        placeholder="Enter Password"
        placeholderTextColor="#94a3b8"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
      />

      <View style={{ marginTop: 20, width: "60%" }}>
        <Button title="Login" color="#3b82f6" onPress={handleLogin} />
      </View>

      <TouchableOpacity
        style={{ marginTop: 15 }}
        onPress={() => navigation.navigate("Home")}
      >
        <Text style={{ color: "#fbbf24" }}>⬅ Back to Home</Text>
      </TouchableOpacity>
    </View>
  );
}

// -------- Home Screen --------
function Home({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>👋 Welcome to SkillSwap</Text>
      <Button
        title="Go to Login 🔑"
        onPress={() => navigation.navigate("Login")}
        color="#f59e0b"
      />
    </View>
  );
}

// -------- Dashboard Screen --------
function Dashboard() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>📚 SkillSwap Dashboard</Text>
      <Text style={styles.text}>Welcome! You are logged in ✅</Text>
    </View>
  );
}

// -------- Main App --------
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={Home} />
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="Dashboard" component={Dashboard} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

// -------- Styles --------
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#1e293b",
    alignItems: "center",
    justifyContent: "center",
    padding: 20,
  },
  title: {
    fontSize: 24,
    color: "#fbbf24",
    marginBottom: 20,
    fontWeight: "bold",
    textAlign: "center",
  },
  input: {
    width: "80%",
    borderWidth: 1,
    borderColor: "#475569",
    backgroundColor: "#334155",
    borderRadius: 8,
    padding: 10,
    marginBottom: 15,
    color: "#f1f5f9",
  },
  text: {
    fontSize: 18,
    color: "#f1f5f9",
    marginTop: 15,
  },
});
