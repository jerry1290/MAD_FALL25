import React, { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet } from "react-native";

export default function App() {
  const [user, setUser] = useState(null);
  const [name, setName] = useState("");
  const [skills, setSkills] = useState("");
  const [availableSkills] = useState([
    { id: "1", skill: "📘 English Speaking" },
    { id: "2", skill: "💻 Web Development" },
    { id: "3", skill: "🎸 Guitar" },
    { id: "4", skill: "🎨 Graphic Design" },
    { id: "5", skill: "🧮 Mathematics" },
  ]);
  const [requests, setRequests] = useState([]);

  const handleSignup = () => {
    if (name && skills) {
      setUser({ name, skills });
    }
  };

  const handleRequest = (item) => {
    setRequests((prev) => [...prev, `You requested: ${item.skill}`]);
  };

  const handleBack = () => {
    setUser(null);   // back karne pr user ko reset kar dega
    setRequests([]); // requests bhi clear kar dega
  };

  if (!user) {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>🌟 SkillSwap App</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter your name"
          value={name}
          onChangeText={setName}
        />
        <TextInput
          style={styles.input}
          placeholder="Enter your skill (e.g. Cooking)"
          value={skills}
          onChangeText={setSkills}
        />
        <TouchableOpacity style={styles.button} onPress={handleSignup}>
          <Text style={styles.buttonText}>Sign Up</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>👋 Welcome {user.name}!</Text>
      <Text style={styles.subtitle}>Your Skill: {user.skills}</Text>

      <Text style={styles.sectionTitle}>🔍 Available Skills</Text>
      <FlatList
        data={availableSkills}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.skillItem} onPress={() => handleRequest(item)}>
            <Text style={styles.skillText}>{item.skill}</Text>
          </TouchableOpacity>
        )}
      />

      <Text style={styles.sectionTitle}>📩 Your Requests</Text>
      {requests.map((req, index) => (
        <Text key={index} style={styles.requestText}>
          {req}
        </Text>
      ))}

      {/* Back Button */}
      <TouchableOpacity style={[styles.button, { marginTop: 20 }]} onPress={handleBack}>
        <Text style={styles.buttonText}>⬅ Back</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#1e293b",
    padding: 20,
    paddingTop: 50,
  },
  title: {
    fontSize: 26,
    fontWeight: "bold",
    marginBottom: 20,
    textAlign: "center",
    color: "#fbbf24",
  },
  subtitle: {
    fontSize: 18,
    color: "#38bdf8",
    marginBottom: 20,
    textAlign: "center",
  },
  sectionTitle: {
    fontSize: 20,
    marginVertical: 10,
    fontWeight: "bold",
    color: "#f59e0b",
  },
  input: {
    backgroundColor: "#fff",
    padding: 10,
    borderRadius: 8,
    marginBottom: 15,
  },
  button: {
    backgroundColor: "#f59e0b",
    padding: 12,
    borderRadius: 8,
  },
  buttonText: {
    color: "#fff",
    fontWeight: "bold",
    textAlign: "center",
  },
  skillItem: {
    backgroundColor: "#334155",
    padding: 12,
    borderRadius: 8,
    marginBottom: 10,
  },
  skillText: {
    color: "#f1f5f9",
    fontSize: 16,
  },
  requestText: {
    color: "#fff",
    marginTop: 5,
  },
});
