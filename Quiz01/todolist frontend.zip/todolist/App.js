// App.js
import React, { useEffect, useState, useRef } from "react";
import {
  SafeAreaView,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  Modal,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  Alert,
  StatusBar,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

const STORAGE_KEY = "@todos_v1";

export default function App() {
  const [todos, setTodos] = useState([]);
  const [filter, setFilter] = useState("All");
  const [modalVisible, setModalVisible] = useState(false);
  const [editingTodo, setEditingTodo] = useState(null);
  const [inputText, setInputText] = useState("");
  const inputRef = useRef(null);

  // Load todos from storage
  useEffect(() => {
    loadTodos();
  }, []);

  // Save todos whenever changed
  useEffect(() => {
    saveTodos(todos);
  }, [todos]);

  const loadTodos = async () => {
    try {
      const raw = await AsyncStorage.getItem(STORAGE_KEY);
      if (raw) setTodos(JSON.parse(raw));
    } catch (e) {
      console.warn("Load error", e);
    }
  };

  const saveTodos = async (nextTodos) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(nextTodos));
    } catch (e) {
      console.warn("Save error", e);
    }
  };

  const openAddModal = () => {
    setEditingTodo(null);
    setInputText("");
    setModalVisible(true);
    setTimeout(() => inputRef.current?.focus?.(), 100);
  };

  const openEditModal = (todo) => {
    setEditingTodo(todo);
    setInputText(todo.title);
    setModalVisible(true);
    setTimeout(() => inputRef.current?.focus?.(), 100);
  };

  const closeModal = () => {
    setModalVisible(false);
    setEditingTodo(null);
    setInputText("");
  };

  const addTodo = () => {
    const title = inputText.trim();
    if (!title) {
      Alert.alert("Empty todo", "Please enter a task.");
      return;
    }
    const newTodo = {
      id: Date.now().toString(),
      title,
      completed: false,
      createdAt: new Date().toISOString(),
    };
    setTodos([newTodo, ...todos]);
    closeModal();
  };

  const saveEdit = () => {
    const title = inputText.trim();
    if (!title) return;
    setTodos(todos.map((t) => (t.id === editingTodo.id ? { ...t, title } : t)));
    closeModal();
  };

  const toggleComplete = (id) => {
    setTodos(todos.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t)));
  };

  const deleteTodo = (id) => {
    Alert.alert("Delete", "Are you sure?", [
      { text: "Cancel", style: "cancel" },
      { text: "Delete", style: "destructive", onPress: () => setTodos(todos.filter((t) => t.id !== id)) },
    ]);
  };

  const clearCompleted = () => {
    setTodos(todos.filter((t) => !t.completed));
  };

  const filteredTodos = todos.filter((t) => {
    if (filter === "Active") return !t.completed;
    if (filter === "Completed") return t.completed;
    return true;
  });

  const stats = {
    total: todos.length,
    active: todos.filter((t) => !t.completed).length,
    completed: todos.filter((t) => t.completed).length,
  };

  const renderItem = ({ item }) => (
    <View style={styles.todoItem}>
      <TouchableOpacity
        style={[styles.checkBox, item.completed && styles.checkBoxChecked]}
        onPress={() => toggleComplete(item.id)}
      >
        <Text style={styles.checkText}>{item.completed ? "✓" : ""}</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.todoTextWrap} onPress={() => openEditModal(item)}>
        <Text style={[styles.todoTitle, item.completed && styles.todoCompleted]}>{item.title}</Text>
        <Text style={styles.todoMeta}>{new Date(item.createdAt).toLocaleString()}</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.deleteBtn} onPress={() => deleteTodo(item.id)}>
        <Text style={styles.deleteBtnText}>Delete</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" />
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Todo List</Text>
        <TouchableOpacity style={styles.addBtn} onPress={openAddModal}>
          <Text style={styles.addBtnText}>+ Add</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.statsRow}>
        <Text style={styles.statText}>Total: {stats.total}</Text>
        <Text style={styles.statText}>Active: {stats.active}</Text>
        <Text style={styles.statText}>Done: {stats.completed}</Text>
      </View>

      <View style={styles.filterRow}>
        {["All", "Active", "Completed"].map((f) => (
          <TouchableOpacity
            key={f}
            style={[styles.filterBtn, filter === f && styles.filterBtnActive]}
            onPress={() => setFilter(f)}
          >
            <Text style={[styles.filterText, filter === f && styles.filterTextActive]}>{f}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <FlatList
        data={filteredTodos}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        ListEmptyComponent={
          <View style={styles.emptyWrap}>
            <Text style={styles.emptyText}>No todos yet!</Text>
          </View>
        }
        contentContainerStyle={{ paddingBottom: 40 }}
      />

      <View style={styles.footer}>
        <TouchableOpacity style={styles.clearBtn} onPress={clearCompleted}>
          <Text style={styles.clearBtnText}>Clear Completed</Text>
        </TouchableOpacity>
      </View>

      {/* Add/Edit Modal */}
      <Modal animationType="slide" transparent visible={modalVisible} onRequestClose={closeModal}>
        <KeyboardAvoidingView
          style={styles.modalWrap}
          behavior={Platform.OS === "ios" ? "padding" : undefined}
        >
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>
              {editingTodo ? "Edit Todo" : "New Todo"}
            </Text>
            <TextInput
              ref={inputRef}
              style={styles.input}
              placeholder="Enter task..."
              value={inputText}
              onChangeText={setInputText}
            />
            <View style={styles.modalBtns}>
              <TouchableOpacity style={styles.modalBtnCancel} onPress={closeModal}>
                <Text style={styles.modalBtnText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.modalBtnSave}
                onPress={editingTodo ? saveEdit : addTodo}
              >
                <Text style={styles.modalBtnText}>Save</Text>
              </TouchableOpacity>
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f9f9f9", padding: 16 },
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 12 },
  headerTitle: { fontSize: 22, fontWeight: "bold" },
  addBtn: { backgroundColor: "#007bff", paddingVertical: 6, paddingHorizontal: 14, borderRadius: 6 },
  addBtnText: { color: "#fff", fontSize: 16 },

  statsRow: { flexDirection: "row", justifyContent: "space-around", marginVertical: 6 },
  statText: { fontSize: 14, color: "#444" },

  filterRow: { flexDirection: "row", justifyContent: "center", marginBottom: 10 },
  filterBtn: { marginHorizontal: 8, paddingVertical: 4, paddingHorizontal: 12, borderRadius: 20, backgroundColor: "#ddd" },
  filterBtnActive: { backgroundColor: "#007bff" },
  filterText: { fontSize: 14, color: "#000" },
  filterTextActive: { color: "#fff", fontWeight: "bold" },

  todoItem: { flexDirection: "row", alignItems: "center", paddingVertical: 10, borderBottomWidth: 1, borderColor: "#ddd" },
  checkBox: { width: 26, height: 26, borderWidth: 2, borderColor: "#007bff", borderRadius: 4, justifyContent: "center", alignItems: "center", marginRight: 10 },
  checkBoxChecked: { backgroundColor: "#007bff" },
  checkText: { color: "#fff", fontWeight: "bold" },
  todoTextWrap: { flex: 1 },
  todoTitle: { fontSize: 16 },
  todoCompleted: { textDecorationLine: "line-through", color: "#888" },
  todoMeta: { fontSize: 11, color: "#666" },
  deleteBtn: { marginLeft: 10 },
  deleteBtnText: { color: "red" },

  emptyWrap: { padding: 20, alignItems: "center" },
  emptyText: { color: "#666" },

  footer: { padding: 10, alignItems: "center" },
  clearBtn: { backgroundColor: "#dc3545", paddingVertical: 6, paddingHorizontal: 16, borderRadius: 6 },
  clearBtnText: { color: "#fff" },

  modalWrap: { flex: 1, justifyContent: "center", alignItems: "center", backgroundColor: "rgba(0,0,0,0.3)" },
  modalContent: { backgroundColor: "#fff", padding: 20, borderRadius: 10, width: "85%" },
  modalTitle: { fontSize: 18, fontWeight: "bold", marginBottom: 10 },
  input: { borderWidth: 1, borderColor: "#ccc", borderRadius: 6, padding: 10, marginBottom: 15 },
  modalBtns: { flexDirection: "row", justifyContent: "flex-end" },
  modalBtnCancel: { marginRight: 10 },
  modalBtnSave: { backgroundColor: "#007bff", paddingHorizontal: 16, paddingVertical: 8, borderRadius: 6 },
  modalBtnText: { color: "#fff", fontWeight: "bold" },
});
